#include <iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL2_gfxPrimitives.h>

using namespace std;

int main(int argc, char* argv[]){

    cout << "testando as bibis do SDL2" << endl;

    return 0;

}
