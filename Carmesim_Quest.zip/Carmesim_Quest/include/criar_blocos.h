#ifdef CRIA_BLOCOS

#define CRIAR_BLOCOS

